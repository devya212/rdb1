package com.nucleus.connection;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class ConnectionClass {
	
	Connection con=null;
	
	FileReader reader=null;

	public Connection getDbConnection() //getting the connection
	{
		try {
			
			reader=new FileReader("D:\\DevyaniPractice\\Brd2\\src\\db.properties");
			Properties properties=new Properties();
			properties.load(reader);
			Class.forName(properties.getProperty("drivername"));
			
			con=DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("username"),properties.getProperty("password"));
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		finally
		{
			try {
				reader.close();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}
		
	return con;	
		
	}

	
	public void closeConnection()//closing connection
	{
		try {
			con.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

		
	}


}
