package com.nucleus.service;

import com.nucleus.dao.IUserDao;
import com.nucleus.dao.UserDaoRDBMSImpl;
import com.nucleus.model.User;

public class UserServiceImpl implements IUserService{
	IUserDao iu=new UserDaoRDBMSImpl();

	@Override
	public boolean validLogin(User user) {
		boolean check=iu.validLogin(user);
		return check;
	}
	

}
