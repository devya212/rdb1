package com.nucleus.dao;

import com.nucleus.model.User;

public interface IUserDao {
public boolean validLogin(User user);
}
